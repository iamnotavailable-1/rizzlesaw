package com.hackerrank.fraudlent.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testOncePerRequestFilter() throws Exception {
        MvcResult mvcResult = mockMvc.perform(get("/api/users/count"))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals("normal", mvcResult.getRequest().getAttribute("user"));
    }

    @Test
    public void testWebRequestInterceptor() throws Exception {
        MvcResult mvcResult = mockMvc.perform(get("/api/users/count"))
                .andExpect(status().isOk())
                .andReturn();

        assertEquals(true, mvcResult.getRequest().getAttribute("processed"));
    }
}